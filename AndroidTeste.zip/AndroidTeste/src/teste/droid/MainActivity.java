package teste.droid;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;


public class MainActivity extends Activity


{
    String DadosGravados = "testemysports";
    SQLiteDatabase BancoDados = null;
    
    private EditText CampoNome,CampoPeso,CampoIdade,CampoAltura;
    private Button BotaoSalvar,BotaoLimpar,BotaoCancelar;
    private CheckBox ComboTwitter,ComboFace,ComboGoogle,ComboCaminhada,ComboCorrida,ComboBicicleta;
   
    
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        CampoNome = (EditText) findViewById(R.id.CampoNome);
        CampoIdade = (EditText) findViewById(R.id.CampoIdade);
        CampoPeso = (EditText) findViewById(R.id.CampoPeso);
        CampoAltura = (EditText) findViewById(R.id.CampoAltura);
        
        BotaoSalvar = (Button) findViewById(R.id.BotaoSalvar);
        BotaoLimpar = (Button) findViewById(R.id.BotaoLimpar);
        BotaoCancelar = (Button) findViewById(R.id.BotaoCancelar);
        
        ComboFace = (CheckBox) findViewById(R.id.ComboFace);
        ComboGoogle = (CheckBox) findViewById(R.id.ComboGoogle);
        ComboTwitter = (CheckBox) findViewById(R.id.ComboTwitter);
        ComboCaminhada = (CheckBox) findViewById(R.id.ComboCaminhada);
        ComboCorrida = (CheckBox) findViewById(R.id.ComboCorrida);
        ComboBicicleta = (CheckBox) findViewById(R.id.ComboBicicleta);
        
        
        ClicaSalvar();
        
    }
    public void CriaBanco(){
        try {
            BancoDados = openOrCreateDatabase(DadosGravados, MODE_WORLD_READABLE, null);
            String SQL = "create table if not exist cadastroatleta (_id INTEGER PRIMARY KEY, CampoNome text, CampoIdade text)";
            BancoDados.execSQL(SQL);
        } catch (Exception e) {
            System.out.println("ERRO BANCO" + e);
        }
    
    }
    public void GravaBanco(){
    
        try {
            BancoDados = openOrCreateDatabase(DadosGravados, MODE_WORLD_READABLE, null);
            String SQL = "INSERT INTO cadastroatleta (CampoNome,CampoIdade) VALUES (CampoNome = '"+CampoNome+"',CampoIdade = '"+CampoIdade+"')";
        } catch (Exception e) {
            System.out.println("ERRO BANCO" + e);
        }
        
    }
        private void ClicaSalvar() {
        
            BotaoSalvar.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {
                    
                    CriaBanco();
                    GravaBanco();
                    //teste abaixo
                    CampoIdade.setText(CampoPeso.getText());
                   //CampoAltura.setText("chegou");
                }
            });
    }
}
